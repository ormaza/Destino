
<p align="center">
<img src="https://colorlib.com/preview/theme/destino/images/logo.png" alt="Logo" width="80" height="60">

  <h3 align="center">Destino</h3>

  <p align="center">
    Aplicação para controle de pacote de viagens
    <br />
    <a href="https://drive.google.com/drive/folders/1o-yqEtx8MBkDtKteJ1PhL9NsWHAte8wy?usp=sharing"><strong>Veja as documentações »</strong></a>
    <br />
    <a href="">Demonstração do sistema</a>
  </p>
</p>


## Conteúdo

* [Sobre o projeto](#sobre-o-projeto)
* [Configuração](#configuração)
  * [Softwares necessários](#softwares-necessários)
  * [Pré-requisitos](#pré-requisitos)
  * [Instalação](#instalação)
* [Contribuição](#contribuição)
* [Licença](#licença)
* [Contato](#contato)



## Sobre o projeto


Descrição aqui...

## Configuração

Esse projeto pode ser executado nos modos de desenvolvimento ou produção.
Abaixo seguem apenas as instruções para desenvolvimento.

### Softwares necessários
* [NodeJs](https://nodejs.org/en/download/)

### Pré-requisitos

* Angular CLI
```sh
npm install -g @angular/cli
```

### Instalação

1. Clone o projeto
```sh
git clone https://gitlab.com/imd-dev/pacote-de-viagens/web-pacote-de-viagens.git
```
2. Vá até a pasta raiz
```sh
cd web-pacote-de-viagens
```
3. Instale as dependências
```sh
npm install
```
4. Suba o projeto em modo de desenvolvimento
```sh
ng serve
```
5. Em seguida acesse `localhost:4200`


## Contribuição

Este projeto procura seguir as boas práticas do [Gitflow](https://br.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow).

1. Clone o projeto  `git clone https://gitlab.com/imd-dev/pacote-de-viagens/web-pacote-de-viagens.git`
2. Vá para a branch de desenvolvimento `git checkout develop`
3. Crie uma branch para uma nova feature `git checkout -b feature_branch`
4. Depois de terminá-la, mescle-a com a de desenvolvimento `git checkout develop && git merge feature_branch`
5. Crie uma nova branch de release(como forma de versionaro do sistema) `git checkout -b release/0.1.0`
6. Finalmente, lance o código para produção `git checkout master && git merge release/0.1.0`



## Licença

Este projeto foi criado com a tecnologia [CoreUI](https://coreui.io/angular/) (Documentação). Mais informações sobre sua licença clique [aqui](https://github.com/coreui/coreui-free-angular-admin-template/blob/master/LICENSE).


## Contato

Ormazabal - ormazabalnascimento@gmail.com

Yuri - yurirdn@ufrn.edu.br