import { CanActivateAdminGuard } from './../../services/CanActivateAdminGuard';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponent } from './list/list.component';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Auditoria'
    },
    canActivate:[ CanActivateAdminGuard],
    children: [
      {
        path: '',
        component: ListComponent,
        data: {
          title: 'Listar'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuditoriaRoutingModule {}
