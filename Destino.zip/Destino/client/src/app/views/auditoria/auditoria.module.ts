import { CanActivateAdminGuard } from './../../services/CanActivateAdminGuard';
// Angular
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

// Forms Component
import { ListComponent } from './list/list.component';

// Components Routing
import { AuditoriaRoutingModule } from './auditoria-routing.module';
import { HttpModule } from '@angular/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { ToasterModule } from 'angular2-toaster';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    AuditoriaRoutingModule,
    HttpModule,
    NgxPaginationModule,
    ToasterModule
  ],
  declarations: [
    ListComponent,
  ],
  providers: [
    CanActivateAdminGuard
  ]
})
export class AuditoriaModule { }
