import { Component, Injectable, OnInit } from '@angular/core';
import {ApiService} from '../../../services/api.service';
import { Router} from '@angular/router';
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';
import { AuthService } from '../../../services/auth.service';

@Component({
  templateUrl: 'list.component.html'
})

@Injectable() 
export class ListComponent implements OnInit{

  data: any;
  pageActual: number = 1;
  usuarioAdmin =  false;

  public config: ToasterConfig;

  constructor(
    private service : ApiService,
    private uiService: UiService,
    private authService : AuthService,
    private router: Router) {
      this.config = new ToasterConfig({positionClass: 'toast-bottom-right'});
     }

   ngOnInit(): void {
    this.getData();
    if(this.authService.usuarioAdmin()) this.usuarioAdmin = true;
  }

  private getData(): any {
     this.service.get('pacotes').subscribe(
       (res) => {
       this.data = res;
     }
    );
  }

  private editar(id: any){
    this.router.navigate(['/pacotes',id]);
  }

  private novo(){
    this.router.navigate(['/pacotes/novo']);
  }

  private deletar(id: any) {
    var r = confirm("Tem certeza que deseja remover esse registro?");
    if (r == true) {
      this.service.delete('pacotes/' + id).subscribe(
        sucesso => {
          this.router.navigate(['./usuarios']).then(()=>{this.router.navigate(['/pacotes'])});
        },
        erro => {
          this.uiService.exibirErro('');
        } 
      );
    } 
  }

}
