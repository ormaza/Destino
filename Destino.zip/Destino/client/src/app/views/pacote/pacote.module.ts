// Angular
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

// Forms Component
import { ListComponent } from './list/list.component';
import { FormComponent } from './form/form.component';

// Components Routing
import { PacoteRoutingModule } from './pacote-routing.module';
import { HttpModule } from '@angular/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { ToasterModule } from 'angular2-toaster';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    PacoteRoutingModule,
    HttpModule,
    NgxPaginationModule,
    ToasterModule
  ],
  declarations: [
    ListComponent,
    FormComponent
  ]
})
export class PacoteModule { }
