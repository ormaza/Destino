import { Component, OnInit, Input } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Pacote } from '../../../models/pacote'
import { TipoServico } from '../../../models/tiposervico';
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';
import { Servico } from '../../../models/servico';

@Component({
  templateUrl: 'form.component.html'
})
export class FormComponent implements OnInit {

  listTipos: any;
  listPacotes: any;

  servicoItem: Servico = new Servico();
  pacoteItem: Pacote = new Pacote();
  isNovo: boolean;
  id: number;
  title: string;

  public config: ToasterConfig;

  constructor(
    private service : ApiService,
    private uiService: UiService,
    private router: Router,
    private route: ActivatedRoute) {
      this.config = new ToasterConfig({positionClass: 'toast-bottom-right'});
     }

  ngOnInit(): void {
    this.getTipos();
    this.getPacote();
  }

  private setEdicao(isEdit: boolean) {
    if(isEdit) {
      this.isNovo = false;
      this.title = "Editar"
    } else {
      this.isNovo = true;
      this.title = "Cadastrar"
    }
  }

  private getTipos() {
    this.listTipos = TipoServico;
  }

 private getPacote(): any {
  this.id = +this.route.snapshot.params['id'];
  if(this.id) {
    this.service.getItem('pacotes',this.id).subscribe(
      (res) => {
      this.pacoteItem = res;
    }
   );
   this.setEdicao(true);
  } else {
    this.setEdicao(false);
  }
}

public salvar(item: Pacote) {
  if(this.isNovo) {
    this.service.post('pacotes', item).subscribe(
      sucesso => {
        this.uiService.exibirSucesso(sucesso['message'], 'Item cadastrado com sucesso!');
        setTimeout(() => {
          this.router.navigate(['/pacotes']);
        }, 1000);
      },
      erro => {
        this.uiService.exibirErro('');
      } 
    );
  } else {
    this.service.put('pacotes/' + this.id, item).subscribe(
      sucesso => {
        this.uiService.exibirSucesso('', 'Item atualizado com sucesso!');
        setTimeout(() => {
          this.router.navigate(['/pacotes']);
        }, 1000);
      },
      erro => {
        this.uiService.exibirErro('');
      } 
    );
  }
}

  // Servicos

  private editarServico(id: any) {
    this.router.navigate(['/servicos',id]);
  }

  private deletarServico(id: any) {
    var r = confirm("Tem certeza que deseja remover esse registro?");
    if (r == true) {
      this.service.delete('servicos/' + id).subscribe(
        sucesso => {
          this.router.navigate(['./usuarios']).then(()=>{this.router.navigate(['/pacotes'+id])});
        },
        erro => {
          this.uiService.exibirErro('');
        } 
      );
    } 
  }

}
