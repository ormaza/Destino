import { CanActivateAdminGuard } from './../../services/CanActivateAdminGuard';
// Angular
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

// Forms Component
import { ListComponent } from './list/list.component';

// Components Routing
import { LogRoutingModule } from './log-routing.module';
import { HttpModule } from '@angular/http';
import { DetailComponent } from './detail/detail.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { ToasterModule } from 'angular2-toaster';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    LogRoutingModule,
    HttpModule,
    NgxPaginationModule,
    ToasterModule
  ],
  declarations: [
    ListComponent,
    DetailComponent
  ],
  providers: [
    CanActivateAdminGuard
  ]
})
export class LogModule { }
