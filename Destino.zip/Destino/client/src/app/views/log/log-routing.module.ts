import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponent } from './list/list.component';
import { DetailComponent } from './detail/detail.component';
import { CanActivateAdminGuard } from '../../services/CanActivateAdminGuard';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Logs'
    },
    canActivate: [CanActivateAdminGuard],
    children: [
      {
        path: '',
        component: ListComponent,
        data: {
          title: 'Listar'
        }
      },
      {
        path: ':id',
        component: DetailComponent,
        data: {
          title: 'Detalhes'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LogRoutingModule {}
