import { Component, Injectable, OnInit, ViewChild } from '@angular/core';
import {ApiService} from '../../../services/api.service';
import { Router} from '@angular/router';
import { Location } from '@angular/common';
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';
import {ModalDirective} from 'ngx-bootstrap/modal';

@Component({
  templateUrl: 'list.component.html'
})

@Injectable() 
export class ListComponent implements OnInit{

  @ViewChild('infoModal', {static: false}) public infoModal: ModalDirective;

  data: any;
  pageActual: number = 1;

  public config: ToasterConfig;

  constructor(
    private service: ApiService,
    private uiService: UiService,
    private router: Router) {
      this.config = new ToasterConfig({positionClass: 'toast-bottom-right'});
    }

   ngOnInit(): void {
    this.getData();
  }

  private getData(): any {
     this.service.get('logs').subscribe(
       (res) => {
       this.data = res;
     }
    );
  }

  private detalhes(id: any){
    this.router.navigate(['/logs',id]);
  }

}
