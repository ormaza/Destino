import { Component, OnInit, Input } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Log } from '../../../models/log'
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';

@Component({
  templateUrl: 'detail.component.html'
})
export class DetailComponent implements OnInit {

  logItem: Log = new Log();

  public config: ToasterConfig;

  constructor(
    private service: ApiService,
    private router: Router,
    private uiService: UiService,
    private route: ActivatedRoute) {
        this.config = new ToasterConfig({positionClass: 'toast-bottom-right'});
    }

  ngOnInit(): void {
    this.getLog();
  }

  private getLog(): any {
      this.service.getItem('logs', +this.route.snapshot.params['id']).subscribe(
        (res) => {
        this.logItem = res;
      }
    );
  }

}
