import { AuthService } from './../../services/auth.service';
import { Component, OnInit, ViewChild, AfterViewChecked } from '@angular/core';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';

import {ApiService} from '../../services/api.service';

import { NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import { Pacote } from '../../models/pacote';
declare var $: any;

@Component({
  templateUrl: 'dashboard.component.html'
})
export class DashboardComponent implements OnInit {

  usuarioAdmin = false;
  
  constructor(
    private service: ApiService,
    private authService: AuthService
    ) { 
      this.usuarioAdmin = this.authService.usuarioAdmin();
    }

    countUsuarios: number;
    countPacotes: number;
    countVendas: number;

    pacotes: Pacote[];

    titleServicos: string;
    countServicos: number;

    images = [1,2,3,4,5,6,7,8,9,10].map(() => `https://picsum.photos/900/500?random&t=${Math.random()}`);

    paused = false;
    unpauseOnArrow = false;
    pauseOnIndicator = false;
    pauseOnHover = true;

    @ViewChild('carousel', {static : true}) carousel: NgbCarousel;

  ngOnInit(): void {
    setTimeout(()=>{ this.getUsuarios(); }, 200);
    setTimeout(()=>{ this.getPacotes(); }, 500);
    setTimeout(()=>{ this.getServicos(); }, 800);
    setTimeout(()=>{ this.getVendas(); }, 1000);
  }

  private getUsuarios(): any {
    this.service.get('admin/usuarios').subscribe(
      (res) => {
      this.countUsuarios = res.length;
    }
   );
 }

 private getPacotes(): any {
  this.service.get('pacotes').subscribe(
    (res) => {
    this.countPacotes = res.length;
    this.pacotes = res;
  }
 );
}

private getServicos(): any {
  this.service.get('servicos').subscribe(
    (res) => {
    this.countServicos = res.length;
    this.titleServicos = "Serviços Cadastrados";
  }
 );
}
private getMediaServicos(): any {
  if(this.countPacotes == null) this.getPacotes();
  this.service.get('servicos').subscribe(
    (res) => {
    this.countServicos = res.length/this.countPacotes;
    this.titleServicos = "Média de Serviços Cadastrados";
  }
 );
}

private getVendas(): any {
  this.service.get('historicos/todos').subscribe(
    (res) => {
    this.countVendas = res.length;
  }
 );
}

  togglePaused() {
    if (this.paused) {
      this.carousel.cycle();
    } else {
      this.carousel.pause();
    }
    this.paused = !this.paused;
  }

  onSlide(slideEvent: NgbSlideEvent) {
    if (this.unpauseOnArrow && slideEvent.paused &&
      (slideEvent.source === NgbSlideEventSource.ARROW_LEFT || slideEvent.source === NgbSlideEventSource.ARROW_RIGHT)) {
      this.togglePaused();
    }
    if (this.pauseOnIndicator && !slideEvent.paused && slideEvent.source === NgbSlideEventSource.INDICATOR) {
      this.togglePaused();
    }
  }

}
