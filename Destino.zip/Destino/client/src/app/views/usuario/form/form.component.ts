import { Component, OnInit, Input } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Usuario } from '../../../models/usuario'
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';

@Component({
  templateUrl: 'form.component.html'
})
export class FormComponent implements OnInit {

  usuarioItem: Usuario = new Usuario();
  isNovo: boolean;
  id: string;
  title: string;

  public config: ToasterConfig;
    
  constructor(
    private service : ApiService,
    private router: Router,
    private uiService: UiService,
    private route: ActivatedRoute) {
        this.config = new ToasterConfig({positionClass: 'toast-bottom-right'});
    }

  ngOnInit(): void {
    this.getUsuario();
  }

 private getUsuario(): any {
  this.id = this.route.snapshot.params['id'];
  if(this.id) {
    this.service.getItem('admin/usuarios',this.id).subscribe(
      (res) => {
      this.usuarioItem = res;
    }
   );
   this.setEdicao(true);
  } else {
    this.setEdicao(false);
  }
}

  public salvar(item: Usuario) {
    if(this.isNovo) {
      item.bloqueado = false;
      this.service.post('admin', item).subscribe(
        sucesso => {
          this.uiService.exibirErro('');
        },
        erro => {
          this.uiService.exibirSucesso('', 'Usuario cadastrado com sucesso!');
          setTimeout(() => {
            this.router.navigate(['/usuarios']);
          }, 1000);
        } 
      );
    } else {
      this.service.put('admin/usuarios/' + this.id, item).subscribe(
        sucesso => {
          this.uiService.exibirSucesso('', 'Item atualizado com sucesso!');
          setTimeout(() => {
            this.router.navigate(['/usuarios']);
          }, 1000);
        },
        erro => {
          this.uiService.exibirErro('');
        } 
      );
    }
  }

  private setEdicao(isEdit: boolean) {
    if(isEdit) {
      this.isNovo = false;
      this.title = "Editar"
    } else {
      this.isNovo = true;
      this.title = "Cadastrar"
    }
  }
}
