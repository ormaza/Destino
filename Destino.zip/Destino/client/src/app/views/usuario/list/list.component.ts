import { Component, Injectable, OnInit } from '@angular/core';
import {ApiService} from '../../../services/api.service';
import { Router} from '@angular/router';
import { Location } from '@angular/common';
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';

@Component({
  templateUrl: 'list.component.html'
})

@Injectable() 
export class ListComponent implements OnInit{

  data: any;
  pageActual: number = 1;

  public config: ToasterConfig;

  constructor(
    private service : ApiService,
    private uiService: UiService,
    private router: Router) {
      this.config = new ToasterConfig({positionClass: 'toast-bottom-right'});
    }

   ngOnInit(): void {
    this.getData();
  }

  private getData(): any {
     this.service.get('admin/usuarios').subscribe(
       (res) => {
       this.data = res;
     }
    );
  }

  public editar(id: any){
    this.router.navigate(['/usuarios',id]);
  }

  public novo(){
    this.router.navigate(['/usuarios/novo']);
  }

}
