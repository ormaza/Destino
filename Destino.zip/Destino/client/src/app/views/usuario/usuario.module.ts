// Angular
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

// Forms Component
import { ListComponent } from './list/list.component';
import { boolFormat } from './../../pipes/boolFormat'

// Components Routing
import { UsuarioRoutingModule } from './usuario-routing.module';
import { HttpModule } from '@angular/http';
import { FormComponent } from './form/form.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { ToasterModule } from 'angular2-toaster';
import { CanActivateAdminGuard } from '../../services/CanActivateAdminGuard';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UsuarioRoutingModule,
    HttpModule,
    NgxPaginationModule,
    ToasterModule
  ],
  declarations: [
    ListComponent,
    FormComponent,
    boolFormat
  ],
  providers: [
    CanActivateAdminGuard
  ]
})
export class UsuarioModule { }
