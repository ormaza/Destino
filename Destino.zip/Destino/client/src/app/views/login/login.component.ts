import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: 'login.component.html'
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;

  constructor(
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.buildForm();
  }

  formularioValido(): boolean {
    // console.log(this.loginForm);
    return (this.loginForm.valid) ? true : false;
  }

  buildForm() {
    this.loginForm = new FormGroup({
      'email': new FormControl(null, [Validators.required, Validators.email]),
      'senha': new FormControl(null, [Validators.required, Validators.minLength(6)]),
    });
  }

  logar() {
    if (this.formularioValido()) {
      this.authService.logarUsuario(this.loginForm.get('email').value, this.loginForm.get('senha').value);
    }
  }
}
