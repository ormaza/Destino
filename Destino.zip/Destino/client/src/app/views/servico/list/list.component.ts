import { AuthService } from './../../../services/auth.service';
import { Component, Injectable, OnInit } from '@angular/core';
import {ApiService} from '../../../services/api.service';
import { Router} from '@angular/router';
import { Location } from '@angular/common';
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';

@Component({
  templateUrl: 'list.component.html'
})

@Injectable() 
export class ListComponent implements OnInit{

  data: any;
  pageActual: number = 1;
  usuarioAdmin =  false;

  public config: ToasterConfig;

  constructor(
    private service : ApiService,
    private authService : AuthService,
    private uiService: UiService,
    private router: Router) {
      this.config = new ToasterConfig({positionClass: 'toast-bottom-right'});
    }

   ngOnInit(): void {
    this.getData();
    if(this.authService.usuarioAdmin()) this.usuarioAdmin = true;
  }

  private getData(): any {
     this.service.get('servicos').subscribe(
       (res) => {
       this.data = res;
     }
    );
  }

  private editar(id: any){
    this.router.navigate(['/servicos',id]);
  }

  private novo(){
    this.router.navigate(['/servicos/novo']);
  }

  private deletar(id: any) {
    var r = confirm("Tem certeza que deseja remover esse registro?");
    if (r == true) {
      this.service.delete('servicos/' + id).subscribe(
        sucesso => {
          this.router.navigate(['./usuarios']).then(()=>{this.router.navigate(['/servicos'])});
        },
        erro => {
          this.uiService.exibirErro('');
        } 
      );
    } 
  }

}
