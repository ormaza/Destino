import { Component, OnInit, Input } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Servico } from '../../../models/servico'
import { TipoServico } from '../../../models/tiposervico';
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';

@Component({
  templateUrl: 'form.component.html'
})
export class FormComponent implements OnInit {

  listTipos: any;
  listPacotes: any;

  servicoItem: Servico = new Servico();
  isNovo: boolean;
  id: number;
  title: string;

  public config: ToasterConfig;
    

  constructor(
    private service : ApiService,
    private router: Router,
    private uiService: UiService,
    private route: ActivatedRoute) {
        this.config = new ToasterConfig({positionClass: 'toast-bottom-right'});
    }

  ngOnInit(): void {
    setTimeout(() => {this.getTipos(); }, 100);
    setTimeout(() => {this.getServico(); }, 200);
    setTimeout(() => {this.getPacotes(); }, 300);
  }

  private getTipos() {
    this.listTipos = TipoServico;
  }

 private getServico(): any {
  this.id = +this.route.snapshot.params['id'];
  if(this.id) {
    this.service.getItem('servicos',this.id).subscribe(
      (res) => {
      this.servicoItem = res;
    }
   );
   this.setEdicao(true);
  } else {
    this.setEdicao(false);
  }
}

private getPacotes(): any {
    this.service.get('pacotes').subscribe(
      (res) => {
      this.listPacotes = res;
    }
   );
}

  public salvar(item: Object) {
    if(this.isNovo) {
      this.service.post('servicos', item).subscribe(
        sucesso => {
          this.uiService.exibirSucesso(sucesso['message'], 'Item cadastrado com sucesso!');
          setTimeout(() => {
            this.router.navigate(['/servicos']);
          }, 1000);
        },
        erro => {
          this.uiService.exibirErro('');
        } 
      );
    } else {
      this.service.put('servicos/' + this.id, item).subscribe(
        sucesso => {
          this.uiService.exibirSucesso('', 'Item atualizado com sucesso!');
          setTimeout(() => {
            this.router.navigate(['/servicos']);
          }, 1000);
        },
        erro => {
          this.uiService.exibirErro('');
        } 
      );
    }
  }

  private setEdicao(isEdit: boolean) {
    if(isEdit) {
      this.isNovo = false;
      this.title = "Editar"
    } else {
      this.isNovo = true;
      this.title = "Cadastrar"
    }
  }
}
