import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponent } from './list/list.component';
import { FormComponent } from './form/form.component';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Serviços'
    },
    children: [
      {
        path: '',
        component: ListComponent,
        data: {
          title: 'Listar'
        }
      },
      {
        path: 'novo',
        component: FormComponent,
        data: {
          title: 'Cadastrar'
        }
      },
      {
        path: ':id',
        component: FormComponent,
        data: {
          title: 'Editar'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ServicoRoutingModule {}
