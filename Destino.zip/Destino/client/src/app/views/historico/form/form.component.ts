import { Component, OnInit, Input } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Servico } from '../../../models/servico'
import { TipoServico } from '../../../models/tiposervico';
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';
import { Historico } from '../../../models/historico';
import { Pacote } from '../../../models/pacote';

@Component({
  templateUrl: 'form.component.html'
})
export class FormComponent implements OnInit {

  listPacotes: any;
  pacoteItem: Pacote = new Pacote();
  showInfo: boolean;

  historicoItem: Historico = new Historico();
  isNovo: boolean;
  id: number;
  title: string;
  valorTotal: number;

  public config: ToasterConfig;
    

  constructor(
    private service : ApiService,
    private router: Router,
    private uiService: UiService,
    private route: ActivatedRoute) {
        this.config = new ToasterConfig({positionClass: 'toast-bottom-right'});
    }

  ngOnInit(): void {
    this.getCompra();
  }

 private getCompra(): any {
  this.id = +this.route.snapshot.params['id'];
  if(this.id) {
    this.service.getItem('historicos',this.id).subscribe(
      (res) => {
      this.historicoItem = res;
      this.getPacote(this.historicoItem.pacote.id);
    }
   );
   this.setNovo(false);
  } else {
    this.setNovo(true);
    this.getAllPacote();
  }
}

private getAllPacote(): any {
  this.service.get('pacotes').subscribe(
    (res) => {
    this.listPacotes = res;
  }
 );
}

private getPacote(id): any {
  this.service.getItem('pacotes', id).subscribe(
    (res) => {
    this.pacoteItem = res;
    this.showInfo = true;
    this.valorTotal = this.getTotal(this.pacoteItem);
  }
 );
}

private getTotal(pacote: Pacote): number{
  var sum = pacote.valor;
  for(var i = 0; i < pacote.servicos.length; i++) sum += pacote.servicos[i].valor;
  return sum;
}

  public salvar(item: Historico) {
    item.pacote = this.pacoteItem;
    if(this.isNovo) {
      this.service.post('historicos', item).subscribe(
        sucesso => {
          this.uiService.exibirSucesso(sucesso['message'], 'Item cadastrado com sucesso!');
          setTimeout(() => {
            this.router.navigate(['/historico']);
          }, 1000);
        },
        erro => {
          this.uiService.exibirErro('');
        } 
      );
    }
  }

  private setNovo(isNovo: boolean) {
    if(isNovo) {
      this.isNovo = true;
      this.title = "Nova Compra"
    } else {
      this.isNovo = false;
      this.title = "Visualizar Compra"
    }
  }
}
