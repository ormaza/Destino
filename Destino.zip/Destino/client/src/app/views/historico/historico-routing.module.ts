import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponent } from './list/list.component';
import { FormComponent } from './form/form.component';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Historico'
    },
    children: [
      {
        path: '',
        component: ListComponent,
        data: {
          title: 'Listar'
        }
      },
      {
        path: 'novo',
        component: FormComponent,
        data: {
          title: 'Nova Compra'
        }
      },
      {
        path: ':id',
        component: FormComponent,
        data: {
          title: 'Visualizar'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HistoricoRoutingModule {}
