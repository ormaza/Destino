import { CacheService } from './../../../services/cache.service';
import { Component, OnInit, Input } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Perfil } from '../../../models/perfil'
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';
import { Permissao } from '../../../models/permissao';

@Component({
  templateUrl: 'form.component.html'
})
export class FormComponent implements OnInit {

  listUsuarios: any;
  listPerfis: any;

  permissaoItem: Permissao = new Permissao();
  perfilItem: Perfil = new Perfil();
  isNovo: boolean;
  id: number;
  title: string;

  public config: ToasterConfig;

  constructor(
    private service: ApiService,
    private router: Router,
    private cacheService: CacheService,
    private uiService: UiService) {
    this.config = new ToasterConfig({ positionClass: 'toast-bottom-right' });
  }

  ngOnInit(): void {
    this.switchForm();
  }

  private switchForm(): any {
    if (this.router.url.includes("novo")) {
      this.setNovo(true);
    } else {
      setTimeout(()=>{ this.getPerfis(); }, 100);
      setTimeout(()=>{ this.getUsuarios(); }, 200);
    }
  }

  private getUsuarios(): any {
    this.service.get('admin/usuarios').subscribe(
      (res) => {
        this.listUsuarios = res;
      }
    );
  }

  private getPerfis(): any {
    this.service.get('admin/perfil').subscribe(
      (res) => {
        this.listPerfis = res;
      }
    );
  }

  private salvar(item: Object) {
    var url: string;
    if (this.isNovo) {
      url = 'admin/perfil';
    } else {
      url = 'admin/perfil/atribuir';
    }
    this.service.post(url, item).subscribe(
      sucesso => {
        this.uiService.exibirSucesso('', 'Item cadastrado com sucesso!');
        setTimeout(() => {
          this.router.navigate(['/perfis']);
        }, 1000);
      },
      erro => {
        this.uiService.exibirErro('');
      }
    );
  }

  private setNovo(ehNovo: boolean) {
    if (ehNovo) {
      this.isNovo = true;
      this.title = "Cadastrar";
    } else {
      this.isNovo = false;
      this.title = "Associar";
    }
  }
}
