import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponent } from './list/list.component';
import { FormComponent } from './form/form.component';
import { CanActivateAdminGuard } from '../../services/CanActivateAdminGuard';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Perfis'
    },
    canActivate: [CanActivateAdminGuard],
    children: [
      {
        path: '',
        component: ListComponent,
        data: {
          title: 'Listar'
        }
      },
      {
        path: 'associar',
        component: FormComponent,
        data: {
          title: 'Associar'
        }
      },
      {
        path: 'novo',
        component: FormComponent,
        data: {
          title: 'Novo'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PerfilRoutingModule {}
