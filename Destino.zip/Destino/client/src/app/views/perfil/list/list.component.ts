import { AuthService } from './../../../services/auth.service';
import { Component, Injectable, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { UiService } from '../../../services/ui-service.service';
import { ToasterConfig } from 'angular2-toaster';
import { CacheService } from '../../../services/cache.service';

@Component({
  templateUrl: 'list.component.html'
})

@Injectable()
export class ListComponent implements OnInit {

  data: any;
  pageActual: number = 1;

  public config: ToasterConfig;

  constructor(
    private service: ApiService,
    private cacheService: CacheService,
    private uiService: UiService,
    private authService: AuthService,
    private router: Router) {
    this.config = new ToasterConfig({ positionClass: 'toast-bottom-right' });
  }

  ngOnInit(): void {
    this.getData();
  }

  private getData(): any {
    this.service.get('admin/usuarios').subscribe(
      (res) => {
        this.data = res;
      }
    );
  }

  public associar() {
    this.router.navigate(['/perfis/associar']);
  }

  public novo() {
    this.router.navigate(['/perfis/novo']);
  }

  private deletar(item: Object, nomeRole: string) {
    item['nomePerfil'] = nomeRole;
    item['idUsuario'] = item['id'];
    this.service.post('admin/perfil/desvincular', item).subscribe(
      sucesso => {
        if (this.usuarioSeDesvinculou(item)) {
          this.authService.desLogarUsuario();
          return;
        }
        this.uiService.exibirSucesso('Usuário desvinculado desse perfil.');
        this.router.navigate(['./usuarios']).then(() => { this.router.navigate(['/perfis']) });
      },
      erro => {
        this.uiService.exibirErro('');
      }
    );
  }
  private usuarioSeDesvinculou(usuarioASerDesvinculado: Object): boolean {
    var perfil = this.cacheService.getItem('perfil');
    if (perfil != null && perfil['roles'].includes('Admin')) {
      return perfil["usuario"]["email"] == usuarioASerDesvinculado["email"];
    }
    return false;
  }

}
