import { UiService } from './../../services/ui-service.service';
import { ApiService } from './../../services/api.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl, AbstractControl } from '@angular/forms';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: 'register.component.html'
})
export class RegisterComponent implements OnInit {

  public formulario: FormGroup;


  constructor(
    private apiService: ApiService,
    private uiService: UiService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.buildForm();
  }

  formularioValido(): boolean {
    // console.log(this.formulario);
    return (this.formulario.valid) ? true : false;
  }

  buildForm() {
    this.formulario = new FormGroup({
      'email': new FormControl(null, [Validators.required, Validators.email]),
      'senha': new FormControl(null, [Validators.required, Validators.minLength(6)]),
      'confirmacaoSenha': new FormControl(null, [Validators.required]),
    },
      { validators: this.mesmasSenhas }
    );
  }

  private mesmasSenhas(AC: AbstractControl) {
    let senha = AC.get('senha').value; 
    let confirmacaoSenha = AC.get('confirmacaoSenha').value; 
    if (senha != confirmacaoSenha) {
      // console.log('false');
      AC.get('confirmacaoSenha').setErrors({ senhasDiferentes: true })
    } else {
      // console.log('true');
      return null
    }
  }

  cadastrarUsuario() {
    if (this.formularioValido()) {
      this.apiService.post('usuarios', { Email: this.formulario.get('email').value, ChaveAcesso: this.formulario.get('senha').value }).subscribe(
        sucesso => {
          this.uiService.exibirSucesso("Você foi cadastrado!");
          this.router.navigate(['/login']);
        },
        erro => {
          if (erro['statusCode'] != 500) {
            this.uiService.exibirErro("Formulário inválido!");
          }
        }
      );
    }
  }

}
