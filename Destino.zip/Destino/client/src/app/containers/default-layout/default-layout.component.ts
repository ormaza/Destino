import { Component, OnDestroy, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { navItems } from '../../_nav';
import { AuthService } from '../../services/auth.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './default-layout.component.html'
})
export class DefaultLayoutComponent implements OnDestroy {

  public navItems = navItems;
  public sidebarMinimized = true;
  private changes: MutationObserver;
  public element: HTMLElement;
  private menusParaExcluir = null;

  constructor(private authService: AuthService, @Inject(DOCUMENT) _document?: any) {

    this.menusParaExcluir = ['Usuarios', 'Perfis', 'Log','Auditoria']
    this.menusParaExcluir = JSON.parse(JSON.stringify(this.menusParaExcluir));

    this.changes = new MutationObserver((mutations) => {
      this.sidebarMinimized = _document.body.classList.contains('sidebar-minimized');
    });
    this.element = _document.body;
    this.changes.observe(<Element>this.element, {
      attributes: true,
      attributeFilter: ['class']
    });

    this.excluirMenusParaUsuarioComum();
  }

  private excluirMenusParaUsuarioComum() {
    if (!this.authService.usuarioAdmin()) {
      this.navItems = this.navItems.filter(item => !this.menusParaExcluir.includes( item['name']));
    }
  }

  deslogar(){
    this.authService.desLogarUsuario();
  }

  ngOnDestroy(): void {
    this.changes.disconnect();
  }
}
