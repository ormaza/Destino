import { CanLoad, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';

@Injectable()
export class AdminGuard implements CanLoad {
    constructor(
        private authService: AuthService,
        private router: Router,

    ) { }

    canLoad(route: import("@angular/router").Route, segments: import("@angular/router").UrlSegment[]): boolean | import("rxjs").Observable<boolean> | Promise<boolean> {
        if (this.authService.usuarioAdmin()) {
            return true;
        }
        return false;
    }
}