import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { CacheService } from './cache.service';
import { UiService } from './ui-service.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private apiService: ApiService,
    private cacheServie: CacheService,
    private uiService: UiService,
    private router: Router,

  ) { }

  logarUsuario(email: string, senha: string) {
    this.apiService.post('login', { Email: email, ChaveAcesso: senha }).subscribe(
      sucesso => {
        this.cacheServie.setItem('token', sucesso);
        this.buscarPerfilUsuario();
      },
      erro => {
        if(erro['statusCode'] != 500){
          this.uiService.exibirErro("Usuario e/ ou senha inválidos!");
        }
      }
    );
  }

  desLogarUsuario() {
    this.cacheServie.clear();
    this.router.navigate(['/login']);
  }

  buscarPerfilUsuario() {
    this.apiService.get('usuarios/perfil').subscribe(
      sucesso => {
        this.cacheServie.setItem('perfil', sucesso);
        this.uiService.exibirSucesso("Seja Bem-Vindo!", 'Atenticado com sucesso!');
        this.router.navigate(['dashboard']);
        this.usuarioAdmin();
      },
      erro => {
        console.log(erro);
        if(erro['statusCode'] != 500){
          this.uiService.exibirErro("Usuario e/ ou senha inválidos!");
        }
      }
    );
  }

  usuarioAtenticado(): boolean {
    return this.cacheServie.getItem("perfil") != null;
  }

  usuarioAdmin(): boolean {
    var perfil = this.cacheServie.getItem("perfil");
    if(perfil != null){
      return perfil['roles'].includes('Admin');
    }
    return false;
  }
}
