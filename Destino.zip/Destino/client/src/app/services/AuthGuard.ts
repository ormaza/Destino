import { CanLoad, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';

@Injectable()
export class AuthGuard implements CanLoad {
    constructor(
        private authService: AuthService,
        private router: Router,

    ) { }

    canLoad(route: import("@angular/router").Route, segments: import("@angular/router").UrlSegment[]): boolean | import("rxjs").Observable<boolean> | Promise<boolean> {
        if (this.authService.usuarioAtenticado()) {
            return true;
        }
        this.router.navigate(['login']);
        return false;
    }
}