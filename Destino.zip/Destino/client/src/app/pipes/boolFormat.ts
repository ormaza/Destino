import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'boolFormat' })
export class boolFormat implements PipeTransform {
    transform(value: boolean): string {
        return value == true ? 'Bloqueado' : 'Desbloqueado'
    }; 
}