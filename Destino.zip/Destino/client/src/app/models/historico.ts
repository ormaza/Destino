import { Pacote } from './pacote';
import { Usuario } from './usuario';

export class Historico {
    id: number;
    pacote: Pacote;
    usuario: Usuario;
  }