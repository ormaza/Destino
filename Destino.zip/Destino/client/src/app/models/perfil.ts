export class Perfil {
    id: number;
    nome: string;
}