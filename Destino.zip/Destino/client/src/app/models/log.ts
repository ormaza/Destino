export class Log {
    id: number;
    timestamp: string;
    level: string;
    exception: string;
    renderedMessage: string;
    properties: string;
  }