import { Servico } from './servico';

export class Pacote {
    id: number;
    nome: string;
    categoria: string;
    valor: number;

    destino: string;
    dataIda: any;
    dataVolta: any;
    maxClientes: number;
    servicos: Servico[];
  }