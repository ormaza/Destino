export class Servico {
    id: number;
    pacoteId: number;
    descricao: string;
    tipo: string;
    valor: number;
  }