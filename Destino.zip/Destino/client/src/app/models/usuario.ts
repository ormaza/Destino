export class Usuario {
    id: string;
    chaveAcesso: string;
    email: string;
    bloqueado: boolean;
  }