export const TipoServico: string [] =['Alimentação', 'Estadia', 'Passeio'];
    