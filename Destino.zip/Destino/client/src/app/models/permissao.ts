export class Permissao {
    id: number;
    idUsuario: string;
    idPerfil: string;
  }