import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Import Containers
import { DefaultLayoutComponent } from './containers';

import { P404Component } from './views/error/404.component';
import { LoginComponent } from './views/login/login.component';
import { RegisterComponent } from './views/register/register.component';
import { AuthGuard } from './services/AuthGuard';
import { AdminGuard } from './services/AdminGuard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'login',
    component: LoginComponent,
    data: {
      title: 'Login'
    }
  },
  {
    path: 'cadastro',
    component: RegisterComponent,
    data: {
      title: 'Cadastro'
    }
  },
  {
    path: '',
    component: DefaultLayoutComponent,
    data: {
      title: 'Home'
    },
    children: [
      {
        path: 'charts',
        loadChildren: () => import('./views/chartjs/chartjs.module').then(m => m.ChartJSModule)
      },
      {
        path: 'dashboard',
        loadChildren: () => import('./views/dashboard/dashboard.module').then(m => m.DashboardModule),
        canLoad: [AuthGuard]
      },
      {
        path: 'servicos',
        loadChildren: () => import('./views/servico/servico.module').then(m => m.ServicoModule),
        canLoad: [AuthGuard]
      },
      {
        path: 'pacotes',
        loadChildren: () => import('./views/pacote/pacote.module').then(m => m.PacoteModule),
        canLoad: [AuthGuard]
      },
      {
        path: 'historico',
        loadChildren: () => import('./views/historico/historico.module').then(m => m.HistoricoModule),
        canLoad: [AuthGuard]
      },
      {
        path: 'logs',
        loadChildren: () => import('./views/log/log.module').then(m => m.LogModule),
        canLoad: [AdminGuard]
      },
      {
        path: 'usuarios',
        loadChildren: () => import('./views/usuario/usuario.module').then(m => m.UsuarioModule),
        canLoad: [AdminGuard]
      },
      {
        path: 'perfis',
        loadChildren: () => import('./views/perfil/perfil.module').then(m => m.PerfilModule),
        canLoad: [AdminGuard]
      },
      {
        path: 'auditoria',
        loadChildren: () => import('./views/auditoria/auditoria.module').then(m => m.AuditoriaModule),
        canLoad: [AdminGuard]
      },
    ]
  },
  { path: '**', component: P404Component }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
