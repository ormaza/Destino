﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using APIPacoteViagem.Controllers;
using APIPacoteViagem.Controllers.Middleware;
using APIPacoteViagem.Entidades.Modelos;
using APIPacoteViagem.Infra;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Npgsql.EntityFrameworkCore.PostgreSQL;

namespace APIPacoteViagem {
    public class Startup {
        public Startup (IConfiguration configuration) {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices (IServiceCollection services) {
            services.AddCors ();
            services.AddMvc ()
                .SetCompatibilityVersion (CompatibilityVersion.Version_2_1)
                .AddMvcOptions (o => o.OutputFormatters.Add (new XmlDataContractSerializerOutputFormatter ()));

            services.AddSwaggerGen (c => {
                c.SwaggerDoc ("v1", new OpenApiInfo { Title = "Pacote de Viagens API", Version = "v1" });
            });

            services.AddDbContext<DBViagemContext> (opt => opt.UseNpgsql (Configuration.GetConnectionString ("PostgreSql")));
            services.AddDbContext<DBLogsContext> (opt => opt.UseSqlite (Configuration.GetConnectionString ("SQLite")));

            services.AddIdentity<Usuario, IdentityRole> (options => {
                options.Password.RequiredLength = 6;
                options.Password.RequireNonAlphanumeric = true;
                options.Password.RequireUppercase = true;
                options.User.RequireUniqueEmail = true;
            }).AddEntityFrameworkStores<DBViagemContext> ();

            var SigningConfig = new SigningConfig ();
            services.AddSingleton (SigningConfig);

            var tokenConfig = new TokenConfig ();
            new ConfigureFromConfigurationOptions<TokenConfig> (
                Configuration.GetSection ("TokenConfigs")
            ).Configure (tokenConfig);

            services.AddSingleton (tokenConfig);

            services.AddAuthentication (authOptions => {
                authOptions.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                authOptions.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer (bearerOptions => {
                var paramsValidation = bearerOptions.TokenValidationParameters;
                paramsValidation.IssuerSigningKey = SigningConfig.Key;
                paramsValidation.ValidAudience = tokenConfig.Audience;
                paramsValidation.ValidIssuer = tokenConfig.Issuer;

                paramsValidation.ValidateIssuerSigningKey = true;
                paramsValidation.ValidateLifetime = true;
                paramsValidation.ClockSkew = TimeSpan.Zero;
            });

            services.AddAuthorization (auth => {
                auth.AddPolicy (
                    "Bearer", new Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder ()
                    .AddAuthenticationSchemes (JwtBearerDefaults.AuthenticationScheme)
                    .RequireAuthenticatedUser ().Build ()
                );
            });
            services.AddAuthorization (options => {
                options.AddPolicy ("ApenasAdministrador", policy => policy.RequireRole ("Administrador"));
                // options.AddPolicy("DeletePie", policy => policy.RequireClaim("Delete Pie", "Delete Pie"));
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure (IApplicationBuilder app, IHostingEnvironment env, DBViagemContext dbContext,
            RoleManager<IdentityRole> roleManager, UserManager<Usuario> userManager) {

            if (env.IsDevelopment ()) {
                // app.UseDeveloperExceptionPage();

            } else {
                app.UseHsts ();
            }

            app.UseCors (option => option.WithOrigins ("http://localhost:4200").AllowAnyHeader ().AllowAnyMethod ());

            // app.UseHttpsRedirection();

            app.UseSwagger ();
            app.UseSwaggerUI (c => {
                c.SwaggerEndpoint ("/swagger/v1/swagger.json", "Pacote de Viagens API V1");
                c.RoutePrefix = string.Empty;
            });

            // Handles exceptions and generates a custom response body
            app.UseExceptionHandler ("/errors/500");

            // Handles non-success status codes with empty body
            app.UseStatusCodePagesWithReExecute ("/errors/{0}");

             app.UseMiddleware<LogMiddleware>();

            app.UseMvc ();

            DBInitializer.Seed (dbContext, roleManager, userManager);
        }
    }
}