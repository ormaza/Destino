using System.ComponentModel.DataAnnotations;

namespace APIPacoteViagem.Entidades.DTOs.Create {

    public class PerfilUsuarioDTO {
        public string IdUsuario { get; set; }
        public string NomePerfil { get; set; }
        public string IdPerfil { get; set; }
    }
}