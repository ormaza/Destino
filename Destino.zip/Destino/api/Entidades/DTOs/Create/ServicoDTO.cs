﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace APIPacoteViagem.Entidades.DTOs.Create
{
    public class ServicoDTO
    {
        [Required(ErrorMessage = "O tipo de serviço é obrigatório.")]
        [MaxLength(50)]
        public string Tipo { get; set; }

        [Required(ErrorMessage = "O valor do serviço é obrigatório.")]
        [DataType(DataType.Currency)]
        public double Valor { get; set; }

        [MaxLength(5000)]
        public string Descricao { get; set; }
    }
}
