using System;
using System.ComponentModel.DataAnnotations;

namespace APIPacoteViagem.Entidades.DTOs.Create
{
    public class UsuarioCreateDTO
    {
        [Required(ErrorMessage = "O Email é obrigatório.")]
        [MaxLength(50)]
        public string Email { get; set; }

        [Required(ErrorMessage = "A senha é obrigatória.")]
        public string ChaveAcesso { get; set; }
    }
}