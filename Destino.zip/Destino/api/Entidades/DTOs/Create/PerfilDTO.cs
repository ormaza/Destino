﻿using System.ComponentModel.DataAnnotations;

namespace APIPacoteViagem.Entidades.DTOs.Create
{
    public class PerfilDTO
    {
        [Required(ErrorMessage = "O nome do perfil é obrigatório.")]
        [MaxLength(50)]
        public string Nome { get; set; }
    }
}
