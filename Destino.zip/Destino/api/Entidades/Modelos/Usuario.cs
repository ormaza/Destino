using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace APIPacoteViagem.Entidades.Modelos {
    public class Usuario : IdentityUser {

        [Required (ErrorMessage = "O email é obrigatório.")]
        [MaxLength (50)]
        override  public string Email { get; set; }

        [Required (ErrorMessage = "A senha é obrigatória.")]
        [MaxLength (50)]
        public string ChaveAcesso { get; set; }

        public bool Bloqueado { get; set; }
    }
}