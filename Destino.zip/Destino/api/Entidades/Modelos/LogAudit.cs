﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIPacoteViagem.Entidades.Modelos
{
    public class LogAudit
    {
        public long Id { get; set; }
        public string Ip { get; set; }
        public string Host { get; set; }
        public string Method { get; set; }
        public string Rota { get; set; }
        public string Protocolo { get; set; }
        public DateTime Data { get; set; }
    }
}
