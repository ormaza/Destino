using Microsoft.EntityFrameworkCore;

namespace APIPacoteViagem.Entidades.Modelos
{
    public class ServicoContext : DbContext
    {
        public ServicoContext(DbContextOptions<ServicoContext> options) : base(options)
        {
        }
        
        public DbSet<Servico> Servicos {get; set;}

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
    }
}