using Microsoft.EntityFrameworkCore;

namespace APIPacoteViagem.Entidades.Modelos
{
    public class PacoteContext : DbContext
    {
        public PacoteContext(DbContextOptions<PacoteContext> options) : base(options)
        {
        }

        public DbSet<Pacote> Pacotes {get; set;}

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
    }
}