namespace APIPacoteViagem.Entidades.Modelos
{
    public class Historico
    {
        public long Id { get; set; }
        public Usuario usuario {get; set;}
        public Pacote pacote {get; set;}
    }
}