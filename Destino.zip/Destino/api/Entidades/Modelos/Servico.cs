﻿namespace APIPacoteViagem.Entidades.Modelos
{
    public class Servico
    {
        public long Id { get; set; }
        public long? PacoteId {get; set;}
        public string Tipo { get; set; }
        public double Valor { get; set; }
        public string Descricao { get; set; }
    }
}