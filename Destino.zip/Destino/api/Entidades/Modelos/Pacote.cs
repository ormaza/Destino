﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIPacoteViagem.Entidades.Modelos
{
    public class Pacote
    {
        public long Id { get; set; }
        public string Nome { get; set; }
        public string Categoria { get; set; }
        public double Valor { get; set; }
        public string Destino { get; set; }
        public DateTime DataIda { get; set; }
        public DateTime DataVolta { get; set; }
        public int MaxClientes { get; set; }
        public List<Servico> Servicos { get; set; }

    }
}
