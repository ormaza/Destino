using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using APIPacoteViagem.Entidades.DTOs.Create;
using APIPacoteViagem.Entidades.Modelos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using APIPacoteViagem.Controllers.ErrorHandlers;
using APIPacoteViagem.Infra;
using System.Linq;

namespace APIPacoteViagem.Controllers {

    [Route ("api/admin/perfil")]
    [Authorize ("Bearer")]
    public class PerfilController : Controller {
        private readonly UserManager<Usuario> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly DBViagemContext _context;

        public PerfilController (UserManager<Usuario> userManager, RoleManager<IdentityRole> roleManager, DBViagemContext context) {
            _userManager = userManager;
            _roleManager = roleManager;
            _context = context;

        }

        [ApiExplorerSettings (IgnoreApi = true)]
        public Usuario GetProfile () {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userEmail = claimsIdentity.FindFirst (ClaimTypes.Name)?.Value;
            var usuario = _context.Usuarios
                .Where (u => u.Email == userEmail)
                .FirstOrDefault ();
            return usuario;
        }

        [HttpGet]
        public async Task<IActionResult> GetItems () {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            return Json (_roleManager.Roles);
        }

        [HttpPost]
        public async Task<IActionResult> PostItem ([FromBody] PerfilDTO item) {

            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }

            var role = new IdentityRole {
                Name = item.Nome
            };

            IdentityResult result = await _roleManager.CreateAsync (role);

            if (result.Succeeded) {
                return Json (StatusCode (200, "Perfil " + item.Nome + " cadastrado com sucesso!"));
            }

            foreach (IdentityError error in result.Errors) {
                ModelState.AddModelError ("", error.Description);
            }
            return Json (result.Errors);
        }

        [HttpPost]
        [Route ("atribuir")]
        public async Task<IActionResult> AdicionarPerfilAusuario ([FromBody] PerfilUsuarioDTO item) {

            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }

            var user = await _userManager.FindByIdAsync (item.IdUsuario);
            var role = await _roleManager.FindByIdAsync (item.IdPerfil);

            user.SecurityStamp = "SecurityStamp";
            user.UserName = user.Email;

            var result = await _userManager.AddToRoleAsync (user, role.Name);

            if (result.Succeeded) {
                return Json (StatusCode (200, "Perfil cadastrado com sucesso!"));
            }

            foreach (IdentityError error in result.Errors) {
                ModelState.AddModelError ("", error.Description);
            }

            return Json (result.Errors);
        }

        [HttpPost]
        [Route ("desvincular")]
        public async Task<IActionResult> RemoverPerfilAusuario ([FromBody] PerfilUsuarioDTO item) {

            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }

            var user = _userManager.FindByIdAsync (item.IdUsuario).Result;
            var role = _roleManager.FindByNameAsync (item.NomePerfil).Result;

            var result = await _userManager.RemoveFromRoleAsync (user, role.Name);

            if (result.Succeeded) {
                return Json (StatusCode (200, "Usuário desvinculado!"));
            }

            foreach (IdentityError error in result.Errors) {
                ModelState.AddModelError ("", error.Description);
            }

            return Json (result.Errors);
        }

    }
}