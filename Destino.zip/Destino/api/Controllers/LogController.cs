using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using APIPacoteViagem.Entidades.Modelos;
using APIPacoteViagem.Infra;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using APIPacoteViagem.Controllers.ErrorHandlers;

namespace APIPacoteViagem.Controllers {
    [Route ("api/logs")]
    [Authorize ("Bearer")]
    public class LogController : Controller {
        private readonly DBLogsContext _context;
        private readonly DBViagemContext _Viagemcontext;
        private readonly UserManager<Usuario> _userManager;

        public LogController (DBLogsContext context, DBViagemContext Viagemcontext, UserManager<Usuario> userManager) {
            _context = context;
            _Viagemcontext = Viagemcontext;
            _userManager = userManager;

        }

        [ApiExplorerSettings (IgnoreApi = true)]
        public Usuario GetProfile () {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userEmail = claimsIdentity.FindFirst (ClaimTypes.Name)?.Value;
            var usuario = _Viagemcontext.Usuarios
                .Where (u => u.Email == userEmail)
                .FirstOrDefault ();
            return usuario;
        }

        // GET: api/<controller>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Log>>> GetItems () {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            return await _context.Logs.ToListAsync ();
        }

        [HttpGet]
        [Route ("auditoria")]
        public async Task<ActionResult<IEnumerable<LogAudit>>> GetAuditoria () {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            return await _Viagemcontext.LogsAudit.ToListAsync ();
        }

        // GET api/<controller>/5
        [HttpGet ("{id}")]
        public async Task<ActionResult<Log>> GetItem (long id) {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            var Log = await _context.Logs
                .FirstOrDefaultAsync (i => i.Id == id);

            if (Log == null) {
                return NotFound ();
            }
            return Log;
        }

    }
}