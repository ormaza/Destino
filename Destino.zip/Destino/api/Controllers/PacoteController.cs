﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using APIPacoteViagem.Entidades.Modelos;
using APIPacoteViagem.Infra;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using APIPacoteViagem.Controllers.ErrorHandlers;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIPacoteViagem.Controllers {

    [Route ("api/pacotes")]
    [Authorize ("Bearer")]
    public class PacoteController : Controller {
        private readonly DBViagemContext _context;
        private readonly UserManager<Usuario> _userManager;

        public PacoteController (DBViagemContext context, UserManager<Usuario> userManager) {
            _context = context;
            _userManager = userManager;

        }

        // GET: api/<controller>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Pacote>>> GetItems () {
            return await _context.Pacotes.Include (s => s.Servicos).ToListAsync ();
        }

        [Route ("meus")]
        [HttpGet]
        public Usuario GetMyItems () {
            var usuario = GetProfile ();
            return usuario;
        }

        // GET api/<controller>/5
        [HttpGet ("{id}")]
        public async Task<ActionResult<Pacote>> GetItem (long id) {
            var Pacote = await _context.Pacotes
                .Include (s => s.Servicos)
                .FirstOrDefaultAsync (i => i.Id == id);

            if (Pacote == null) {
                return NotFound ();
            }
            return Pacote;
        }

        // POST api/<controller>
        [HttpPost]
        public async Task<ActionResult<IEnumerable<Pacote>>> PostItem ([FromBody] Pacote item) {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            _context.Pacotes.Add (item);
            await _context.SaveChangesAsync ();

            return CreatedAtAction (nameof (GetItem), new Pacote { Id = item.Id }, item);
        }

        // PUT api/<controller>/5
        [HttpPut ("{id}")]
        public async Task<IActionResult> PutItem (long id, [FromBody] Pacote item) {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            if (id != item.Id) {
                return BadRequest ();
            }

            _context.Entry (item).State = EntityState.Modified;
            await _context.SaveChangesAsync ();

            return NoContent ();
        }

        // DELETE api/<controller>/5
        [HttpDelete ("{id}")]
        public async Task<IActionResult> DeleteItem (long id) {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            var Pacote = await _context.Pacotes
                .Include (s => s.Servicos)
                .FirstOrDefaultAsync (i => i.Id == id);

            if (Pacote == null) {
                return NotFound ();
            }

            _context.Pacotes.Remove (Pacote);
            await _context.SaveChangesAsync ();

            return NoContent ();
        }

        [ApiExplorerSettings (IgnoreApi = true)]
        public Usuario GetProfile () {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userEmail = claimsIdentity.FindFirst (ClaimTypes.Name)?.Value;
            var usuario = _context.Usuarios
                .Where (u => u.Email == userEmail)
                .FirstOrDefault ();
            return usuario;
        }
    }
}