using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using APIPacoteViagem.Infra;
using APIPacoteViagem.Entidades.Modelos;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Dapper;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIPacoteViagem.Controllers
{
    [Route("api/historicos")]
    [Authorize ("Bearer")]
    public class HistoricoController : Controller
    {
        private readonly DBViagemContext _context;
        IConfiguration _configuration;

        public HistoricoController(DBViagemContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // GET: api/<controller>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Historico>>> GetItems()
        {
            string id = GetProfile().Id;

            return await _context.Historicos
                .Include(s => s.pacote)
                .Include(s => s.usuario)
                .Where(s => s.usuario.Id == id)
                .ToListAsync();
        }

        [HttpGet]
        [Route ("todos")]
        public async Task<ActionResult<IEnumerable<Historico>>> GetAll()
        {
            return await _context.Historicos
                .Include(s => s.pacote)
                .Include(s => s.usuario)
                .ToListAsync();
        }

        // GET api/<controller>/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Historico>> GetItem(long id)
        {
            var Historico = await _context.Historicos
            .Include(s => s.pacote)
            .Include(s => s.usuario)
            .FirstOrDefaultAsync(i => i.Id == id);

            if(Historico == null)
            {
                return NotFound();
            }
            return Historico;
        }

        // POST api/<controller>
        [HttpPost]
        public int PostItem([FromBody] Historico item)
        {
            string usuarioId = GetProfile().Id;
            long pacoteId = item.pacote.Id;
            StringBuilder query = new StringBuilder("INSERT INTO public.\"Historicos\" (\"usuarioId\",\"pacoteId\") VALUES ('");
            query.Append(usuarioId);
            query.Append("',");
            query.Append(pacoteId.ToString());
            query.Append(")");

            using (NpgsqlConnection conexao = new NpgsqlConnection(
                _configuration.GetConnectionString("PostgreSql")))
            {
                return conexao.Execute(query.ToString());
            }
        }

    //     // PUT api/<controller>/5
    //     [HttpPut("{id}")]
    //     public async Task<IActionResult> PutItem(long id, [FromBody] Historico item)
    //     {
    //         if(id != item.Id)
    //         {
    //             return BadRequest();
    //         }

    //         _context.Entry(item).State = EntityState.Modified;
    //         await _context.SaveChangesAsync();

    //         return NoContent();
    //    }

    //     // DELETE api/<controller>/5
    //     [HttpDelete("{id}")]
    //     public async Task<IActionResult> DeleteItem(long id)
    //     {
    //         var Historico = await _context.Historicos.FindAsync(id);

    //         if(Historico == null)
    //         {
    //             return NotFound();
    //         }

    //         _context.Historicos.Remove(Historico);
    //         await _context.SaveChangesAsync();

    //         return NoContent();
    //     }

        [ApiExplorerSettings (IgnoreApi = true)]
        public Usuario GetProfile () {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userEmail = claimsIdentity.FindFirst (ClaimTypes.Name)?.Value;
            var usuario = _context.Usuarios
                .Where (u => u.Email == userEmail)
                .FirstOrDefault ();
            return usuario;
        }
    }
}
