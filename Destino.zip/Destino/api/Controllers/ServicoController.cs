﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIPacoteViagem.Entidades.Modelos;
using APIPacoteViagem.Infra;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Npgsql;
using APIPacoteViagem.Controllers.ErrorHandlers;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace APIPacoteViagem.Controllers {

    [Route ("api/servicos")]
    [Authorize ("Bearer")]
    public class ServicoController : Controller {
        private readonly DBViagemContext _context;
        private IConfiguration _config;
        private readonly UserManager<Usuario> _userManager;

        public ServicoController (DBViagemContext context, IConfiguration configuration, UserManager<Usuario> userManager) {
            _context = context;
            _config = configuration;
            _userManager = userManager;

        }

        [ApiExplorerSettings (IgnoreApi = true)]
        public Usuario GetProfile () {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userEmail = claimsIdentity.FindFirst (ClaimTypes.Name)?.Value;
            var usuario = _context.Usuarios
                .Where (u => u.Email == userEmail)
                .FirstOrDefault ();
            return usuario;
        }

        // GET: api/<controller>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Servico>>> GetItems () {
            return await _context.Servicos.ToListAsync ();
        }

        // GET api/<controller>/5
        [HttpGet ("{id}")]
        public async Task<ActionResult<Servico>> GetItem (long id) {
            var Servico = await _context.Servicos.FindAsync (id);

            if (Servico == null) {
                return NotFound ();
            }
            return Servico;
        }

        // POST api/<controller>
        [HttpPost]
        public async Task<ActionResult<IEnumerable<Servico>>> PostItem ([FromBody] Servico item) {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            _context.Servicos.Add (item);
            await _context.SaveChangesAsync ();

            return CreatedAtAction (nameof (GetItem), new Servico { Id = item.Id }, item);
        }

        // PUT api/<controller>/5
        [HttpPut ("{id}")]
        public async Task<IActionResult> PutItem (long id, [FromBody] Servico item) {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            if (id != item.Id) {
                return BadRequest ();
            }

            _context.Entry (item).State = EntityState.Modified;
            await _context.SaveChangesAsync ();

            return NoContent ();
        }

        // DELETE api/<controller>/5
        [HttpDelete ("{id}")]
        public async Task<IActionResult> DeleteItem (long id) {
            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }
            var Servico = await _context.Servicos.FindAsync (id);

            if (Servico == null) {
                return NotFound ();
            }

            _context.Servicos.Remove (Servico);
            await _context.SaveChangesAsync ();

            return NoContent ();
        }
    }
}