using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIPacoteViagem.Controllers.ErrorHandlers;
using APIPacoteViagem.Entidades.DTOs.Create;
using APIPacoteViagem.Entidades.Modelos;
using APIPacoteViagem.Infra;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace APIPacoteViagem.Controllers {
    [Route ("api/usuarios")]
    [Authorize ("Bearer")]
    public class UsuarioController : Controller {

        private readonly UserManager<Usuario> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly DBViagemContext _context;

        public UsuarioController (UserManager<Usuario> userManager, RoleManager<IdentityRole> roleManager, DBViagemContext context) {
            _userManager = userManager;
            _roleManager = roleManager;
            _context = context;
        }

        [HttpGet]
        [Route ("perfil")]
        public async Task<object> GetPerfil () {
            var email = HttpContext.User.Identity.Name;
            var usuario = _context.Usuarios.Where (u => u.Email == email).FirstOrDefault ();
            var roles = await _userManager.GetRolesAsync (usuario);
            var result = new { Usuario = usuario, Roles = roles };
            return result;
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> PostItem ([FromBody] Usuario item) {

            if (!ModelState.IsValid) return BadRequest (ModelState);

            item.SecurityStamp = "SecurityStamp";
            item.UserName = item.Email;
            item.Bloqueado = false;

            _context.Usuarios.Add (item);
            await _context.SaveChangesAsync ();
            return Json (StatusCode (200, "Usuário cadastrado com sucesso!"));
        }
    }
}