using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using APIPacoteViagem.Controllers.ErrorHandlers;
using APIPacoteViagem.Entidades.DTOs.Create;
using APIPacoteViagem.Entidades.Modelos;
using APIPacoteViagem.Infra;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace APIPacoteViagem.Controllers {
    [Route ("api/admin")]
    [Authorize ("Bearer")]
    public class AdminController : Controller {

        private readonly UserManager<Usuario> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly DBViagemContext _context;

        public AdminController (UserManager<Usuario> userManager, RoleManager<IdentityRole> roleManager, DBViagemContext context) {
            _userManager = userManager;
            _roleManager = roleManager;
            _context = context;
        }

        [ApiExplorerSettings (IgnoreApi = true)]
        public Usuario GetProfile () {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userEmail = claimsIdentity.FindFirst (ClaimTypes.Name)?.Value;
            var usuario = _context.Usuarios
                .Where (u => u.Email == userEmail)
                .FirstOrDefault ();
            return usuario;
        }

        [HttpGet]
        [Route ("usuarios")]
        public async Task<object> Get () {

            var result = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (result == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }

            var usuarios = _userManager.Users;
            var usuariosList = new List<object> ();

            foreach (Usuario u in usuarios) {
                Console.WriteLine ("WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW");
                var roles = await GetRoles (u);
                var usuario = new { Usuario = u, Roles = roles };
                usuariosList.Add (usuario);
            }
            return usuariosList;
        }

        private System.Threading.Tasks.Task<System.Collections.Generic.IList<string>> GetRoles (Usuario user) {
            var roles = _userManager.GetRolesAsync (user);
            return roles;
        }

        [HttpGet]
        [Route ("usuarios/{id}")]
        public async Task<object> GetItem (string id) {

            var result = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (result == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }

            var user = _context.Users.FirstOrDefault (u => u.Id == id);

            if (user == null) {
                return NotFound (new NotFoundError ("Esse usuário não existe."));
            }
            return user;
        }

        [HttpPost]
        public async Task<ActionResult<IEnumerable<Usuario>>> PostItem ([FromBody] Usuario item) {

            var usuAdmin = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (usuAdmin == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }

            item.UserName = item.Email;
            IdentityResult result = await _userManager.CreateAsync (item);

            if (result.Succeeded) {
                return StatusCode (200, "Usuário administrador cadastrado com sucesso!");
            }

            foreach (IdentityError error in result.Errors) {
                ModelState.AddModelError ("", error.Description);
            }
            return Json (result.Errors);
        }

        [HttpPut]
        [Route ("usuarios/{id}")]
        public async Task<object> PutItem (string id, [FromBody] Usuario item) {

            var result = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

            if (result == false) {
                return NotFound (new ForbiddenError ("Não autorizado."));
            }

            var user = _context.Users.FirstOrDefault (u => u.Id == id);
            user.ChaveAcesso = item.ChaveAcesso;
            user.Email = item.Email;
            item.UserName = item.Email;
            await _userManager.UpdateAsync (user);
            _context.SaveChanges ();

            return user;
        }

        // [HttpDelete]
        // [Route ("usuarios/{id}")]
        // public async Task<object> BlockItem (string id) {

        //     var result = await _userManager.IsInRoleAsync (GetProfile (), "Admin");

        //     if (result == false) {
        //         return NotFound (new ForbiddenError ("Não autorizado."));
        //     }

        //     var user = _context.Users.FirstOrDefault (u => u.Id == id);
        //     user.Bloqueado = !user.Bloqueado;
        //     user.UserName = user.Email;
        //     await _userManager.UpdateAsync (user);
        //     _context.SaveChanges ();

        //     if (user == null) {
        //         return NotFound (new NotFoundError ("Esse usuário não existe."));
        //     }
        //     return user;
        // }
    }
}