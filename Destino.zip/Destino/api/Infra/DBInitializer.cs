
using APIPacoteViagem.Infra;
using APIPacoteViagem.Entidades.Modelos;
using System.Collections.Generic;
using System.Linq;
using System;
using Microsoft.AspNetCore.Identity;

public static class DBInitializer
{
    public static void Seed(this DBViagemContext context, RoleManager<IdentityRole> roleManager, UserManager<Usuario> userManager)
    {
        if (!context.Pacotes.Any())
        {
            var servicos = new List<Servico>()
            {
                new Servico(){
                    Tipo = "Alimentação",
                    Valor = 100,
                    Descricao = "Café da Manhã, almoço e janta no restaurante tal.",
                },
                new Servico(){
                    Tipo = "Estadia",
                    Valor = 100,
                    Descricao = "Três dias de hospedagem na pousada num sei que das flores.",
                },
                new Servico(){
                    Tipo = "Passeio",
                    Valor = 100,
                    Descricao = "Passeio de Buggy nas Dunas de Genipabu.",
                }
            };

            var pacotes = new List<Pacote>()
            {
                new Pacote()
                {
                     Nome = "Natal",
                     Categoria = "Praias",
                     Valor = 300,
                     Destino = "Natal/RN - Brasil",
                     DataIda = DateTime.Now,
                     DataVolta = DateTime.Now,
                     MaxClientes = 5,
                     Servicos = servicos
                },
            };
            context.Pacotes.AddRange(pacotes);
            context.SaveChanges();

            var usuarios = new List<Usuario>()
            {
                new Usuario()
                {
                     Email = "admin@email.com",
                     UserName = "admin@email.com",
                     SecurityStamp = "null",
                     ChaveAcesso = "admin123",
                     Bloqueado = false,
                },
                new Usuario()
                {
                     Email = "usuario1@email.com",
                     UserName = "usuario1@email.com",
                     SecurityStamp = "null",
                     ChaveAcesso = "chave01",
                     Bloqueado = false,
                },
                new Usuario()
                {
                     Email = "usuario2@email.com",
                     UserName = "usuario2@email.com",
                     SecurityStamp = "null",
                     ChaveAcesso = "chave02",
                     Bloqueado = true,
                },
            };
            context.Usuarios.AddRange(usuarios);
            context.SaveChanges();

            var role = new IdentityRole
            {
                Name = "Admin"
            };
            var result = roleManager.CreateAsync(role).Result;
            userManager.AddToRoleAsync(usuarios[0], "Admin").Wait();

            var historicos = new List<Historico>()
            {
                new Historico()
                {
                    usuario = usuarios[0],
                    pacote = pacotes[0],
                }
            };
            context.Historicos.AddRange(historicos);
            context.SaveChanges();
        }
    }
}

