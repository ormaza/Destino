using APIPacoteViagem.Entidades.Modelos;
using Microsoft.EntityFrameworkCore;

namespace APIPacoteViagem.Infra {
    public class DBLogsContext : DbContext {

        public DBLogsContext (DbContextOptions<DBLogsContext> options) : base (options) { }

        public DbSet<Log> Logs { get; set;}

    }
}