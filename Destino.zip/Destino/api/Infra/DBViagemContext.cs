using Microsoft.EntityFrameworkCore;
using APIPacoteViagem.Entidades.Modelos;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
namespace APIPacoteViagem.Infra
{
    public class DBViagemContext : IdentityDbContext<Usuario>
    {
        public DBViagemContext(DbContextOptions<DBViagemContext> options)
           : base(options)
        {
            Database.Migrate();
        }

        public DbSet<Pacote> Pacotes { get; set; }
        public DbSet<Servico> Servicos { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Historico> Historicos { get; set; }
        public DbSet<LogAudit> LogsAudit { get; set; }
    }
}
