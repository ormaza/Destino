﻿using APIPacoteViagem.Entidades.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIPacoteViagem.Infra.BancoEmMemoria
{
    public class ServicoBM
    {
        public static ServicoBM SERVICOS_ESTATICOS { get; } = new ServicoBM();

        public List<Servico> Servicos { get; set; }

        public ServicoBM()
        {
            Servicos = new List<Servico>()
            {

                new Servico()
                {
                    Id = 1,
                    Tipo = "Hospedagem",
                    Valor = 150.00,
                    Descricao = "Hospedagem no hotel tal, localizado em tal endereço."
                },

                new Servico()
                {
                    Id = 2,
                    Tipo = "Alimentação",
                    Valor = 75.00,
                    Descricao = "Café da manhã almoço e jantar no hotel tal."
                },

                new Servico()
                {
                    Id = 3,
                    Tipo = "Transporte",
                    Valor = 75.00,
                    Descricao = "Visite as principais praias dentro uma van confortável e segura."
                },

            };
        }
    }
}
