﻿using APIPacoteViagem.Entidades.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIPacoteViagem.Infra.BancoEmMemoria
{
    public class PacoteBM
    {
        public static PacoteBM PACOTES_ESTATICOS { get; } = new PacoteBM();

        public List<Pacote> Pacotes { get; set; }

        public PacoteBM()
        {
            Pacotes = new List<Pacote>()
            {

                new Pacote()
                {
                    Id = 1,
                    Nome = "Natal Cidade do Sol",
                    Categoria = "Praias",
                    Valor = 0,
                    Destino = "Natal/RN, Brasil",
                    DataIda = DateTime.Now.AddDays(7),
                    DataVolta = DateTime.Now.AddDays(14),
                    MaxClientes = 4,
                    Servicos  = ServicoBM.SERVICOS_ESTATICOS.Servicos
                },
                new Pacote()
                {
                    Id = 2,
                    Nome = "Fernando de Noronha",
                    Categoria = "Praias",
                    Valor = 0,
                    Destino = "Fernando de Noronha/PE, Brasil",
                    DataIda = DateTime.Now.AddDays(7),
                    DataVolta = DateTime.Now.AddDays(14),
                    MaxClientes = 4,
                    Servicos  = ServicoBM.SERVICOS_ESTATICOS.Servicos
                },
                new Pacote()
                {
                    Id = 3,
                    Nome = "Gramado",
                    Categoria = "Montanhas",
                    Valor = 0,
                    Destino = "Gramado/RS, Brasil",
                    DataIda = DateTime.Now.AddDays(7),
                    DataVolta = DateTime.Now.AddDays(14),
                    MaxClientes = 2,
                    Servicos  = ServicoBM.SERVICOS_ESTATICOS.Servicos
                }

            };
        }
    }
}
