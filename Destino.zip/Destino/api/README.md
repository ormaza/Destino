<p align="center">
<img src="https://colorlib.com/preview/theme/destino/images/logo.png" alt="Logo" width="80" height="60">

  <h3 align="center">Destino</h3>

  <p align="center">
    Aplicação para controle de pacote de viagens
    <br />
    <a href="https://drive.google.com/drive/folders/1o-yqEtx8MBkDtKteJ1PhL9NsWHAte8wy?usp=sharing"><strong>Veja as documentações »</strong></a>
    <br />
    <a href="">Demonstração do sistema</a>
  </p>
</p>


## Conteúdo

* [Sobre o projeto](#sobre-o-projeto)
* [Configuração](#configuração)
  * [Softwares necessários](#softwares-necessários)
  * [Observação](#observação)
  * [Instalação](#instalação)
* [Contato](#contato)



## Sobre o projeto


Web Service do sistema de controle de pacote de viagens, para ser consumido pelo frontend em Angular2.

## Configuração

Abaixo seguem as instruções para subir a aplicação em modo de desenvolvimento.

### Softwares necessários
* [.NET Core 2.2](https://dotnet.microsoft.com/download/dotnet-core/2.2)
* [PostgreSQL 9.6](https://www.postgresql.org/download/)

#### Observação

Caso não queira instalar o PostgreSQL na sua máquina, existe a possibilidade de subir o banco com o Docker-Compose.

#### Atenção arquivo appsettings.json

Alterar string de conexão:

* Se PostgreSQL na máquina local: "PostgreSql": "Server=localhost;Database=Viagem;Port=5432;User id=postgres;Password=sudo;",
* Se PostgreSQL no docker: "PostgreSql": "Server=192.168.99.100;Database=Viagem;Port=5432;User id=postgres;Password=sudo;",

### (No Windows) Instale o Docker Toolbox
* [Docker Toolbox](https://docs.docker.com/toolbox/toolbox_install_windows/)

Crie uma VM Docker

```sh
docker-machine create default
```
Inicie a VM

```sh
docker-machine start
```

Sete as variáveis de ambiente pro Git Bash

```sh
docker-machine env
```

```sh
eval $("C:\Program Files\Docker Toolbox\docker-machine.exe" env)
```

Na pasta raíz do projeto, rode:

```sh
docker-compose -f Infra/docker-compose.yml up
```
##### Após isso, o container com o PostgreSQL estará rodando e acessível no Host Local no endereço: 192.168.99.100:5432

### Instalação

1. Clone o projeto
```sh
git clone https://gitlab.com/imd-dev/pacote-de-viagens/api-pacote-de-viagens.git
```
2. Vá até a pasta raiz
```sh
cd api-pacote-de-viagens
```
3. Instale as dependências
```sh
dotnet restore
```
5. Faça o build do projeto
```sh
dotnet build
```
6. Rode as migrations(Se o servidor de banco estiver ligado, cria os arquivos com o esquema de banco no diretório: Migrations)
```sh
dotnet ef migrations add primeirasmigracoes --context DBViagemContext
```
7. Rode suba sistema(Ao subir pela primeira vez, o esquema de banco será persistido automaticamte, assim como , alguns dados de teste(Seed), no endereço: http://localhost:5000)
```sh
dotnet run
```

## Contato

Ormazabal - ormazabalnascimento@gmail.com

Yuri - yurirdn@ufrn.edu.br